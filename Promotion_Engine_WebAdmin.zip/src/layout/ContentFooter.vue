<template>
  <footer class="footer px-4 p-0">
    <div class="row align-items-center justify-content-lg-between">
      <div class="col-lg-6">
        <div class="copyright text-center text-lg-left text-muted">
          Capstone project © {{ year }}
          <a href="#" class="font-weight-bold ml-1" target="_blank">Promotion Engine</a>
        </div>
      </div>
      <div class="col-lg-6">
        <ul class="nav nav-footer justify-content-center justify-content-lg-end">
          <li class="nav-item">
            <a href="#" class="nav-link" target="_blank">Promotion Engine</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link" target="_blank">About Us</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link" target="_blank">Tutorial</a>
          </li>
          <!-- <li class="nav-item">
            <a href="#" class="nav-link" target="_blank">License</a>
          </li> -->
        </ul>
      </div>
    </div>
  </footer>
</template>
<script>
export default {
  data() {
    return {
      year: new Date().getFullYear(),
    };
  },
};
</script>
<style></style>
