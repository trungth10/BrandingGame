export const API_URL = "https://api-promotion-engine.reso.vn/";
