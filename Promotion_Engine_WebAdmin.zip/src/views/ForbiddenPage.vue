<template>
  <div class="justify-content"><h1>Sorry this link has expired</h1></div>
</template>

<script>
export default {
  name: "forbidden",
};
</script>

<style></style>
